
var x = 5, y = 10
var z = x < y
x > y
x < y
x >= y
x <= y
x == y
x != y
var stdmark = 60
var ispass = stdmark > 49
print("ispass = \(ispass)")
print("ispass = \(!ispass)")


// and &&, or ||
var isLastyear = false
var isGraduated = ispass || isLastyear

var a = true, b = false , c = true
print(a&&b)
print(a||b)
print(a && b || c)
print(!a || (b&&c))
 // ! && ||


