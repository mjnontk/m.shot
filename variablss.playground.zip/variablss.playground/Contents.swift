// variablss
var firstname = "abdullah", seconName = "sami"
firstname = "omar"

var middlename: String
middlename = "Ahmed"

var lastname : String = "salem"
lastname = "mohammed"
var x : Int
x = Int(5.9)

var y : Float = 4.9
y = 3

var z : Double = 2.674365437289
lastname = "ali"
print(middlename + " " + lastname); print(z)

var hasCar = true
hasCar = false

var hasHouse : Bool
hasHouse = true


// constants
let age = 20

let tax : Float = 0.05

let hasPhone : Bool
hasPhone = true

print (hasPhone)



// summary
var name = "saleh" , carName = "Bmw"
var Price : Int = 11
Price = 12

var minprice = 11.5

let Cityname : String
Cityname = "Riyadh"

print(Cityname + " " + carName )
